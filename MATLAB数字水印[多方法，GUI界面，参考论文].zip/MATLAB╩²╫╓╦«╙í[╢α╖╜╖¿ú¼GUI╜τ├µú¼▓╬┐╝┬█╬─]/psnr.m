function psnratio=psnr(f1,f2)
%PSNRATIO=PSNR(F1,F2) RETURNS THE PEAR SIGNAL TO NOISE RATIO (d. f1 and f2 are
%the input vector, matrix, etc. 

f1=f1(:);% make the matrix to vector.
f2=f2(:); 

if length(f1) ~= length(f2)
errordlg('The length of input data doesnt agree!','Signal to Noise Ratio, SNR');
else
Noise = sum( ((f1-f2).*(f1-f2)) ); 
if Noise == 0
psnratio = 'inf';
else
psnratio=10*log10( (length(f1)*max(f1)^2)/Noise );
end
end