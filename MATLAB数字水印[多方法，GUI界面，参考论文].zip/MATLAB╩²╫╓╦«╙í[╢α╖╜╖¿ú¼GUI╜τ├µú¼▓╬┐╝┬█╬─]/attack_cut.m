 %���й� ��
function embedImage=attack_cut(Image,measure)    
Image(1:measure,1:measure)=zeros(measure,measure); 
% Image(1:256,1:256)=zeros(256,256); 
embedImage=Image;
end  