%LSB����Ƕ���㷨
function [waterImage,psntratio]=lsb_embed(mark,rawImage)
[Mc, Nc]=size(rawImage);
[Mm, Nm]=size(mark);

for i=1:Mc 
    for j=1:Nc
        watermark(i,j)=mark(mod(i,Mm)+1,mod(j,Nm)+1);
    end
end
waterImage=double(rawImage);
for i=1:Mc
    for j=1:Nc
        waterImage(i,j)=bitset(waterImage(i,j),1,watermark(i,j));
    end 
end
waterImage=uint8(waterImage);
save waterImage
psntratio=psnr(double(rawImage),double(waterImage));
end