%==================����==============
function embedImage=attack_salt(Image,indensity)
Image=uint8(Image);
embedImage=imnoise(Image,'salt & pepper',indensity) ; 
end
 
 