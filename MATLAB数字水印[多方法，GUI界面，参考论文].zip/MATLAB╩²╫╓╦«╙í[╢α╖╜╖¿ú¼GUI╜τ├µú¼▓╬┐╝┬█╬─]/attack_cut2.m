 %���й� ��
function embedImage=attack_cut2(Image)    
Image=double(Image);
 
Imager=double(Image(:,:,1));
Imageg=double(Image(:,:,2));
Imageb=double(Image(:,:,3));

Imager(1:64,1:64)=zeros(64,64); 
Imageg(1:64,1:64)=zeros(64,64); 
Imageb(1:64,1:64)=zeros(64,64);
embedImage=cat(3,Imager,Imageg,Imageb);
end