%LSB������ȡ�㷨
function [emark,nc1]=lsb_extract(embedImage,rawMark,flag)
S=size(embedImage);
Mm=S(1);Nm=S(2); 
[row,col]=size(rawMark);

for i=1:Mm
    for j=1:Nm
        mark(i,j)=bitget(embedImage(i,j),1);
    end
end
 
mark=255*double(mark);
mark=mark(row+1:2*row,col+1:2*col);
if flag==1
    mark=resorder(mark,111);
end
nc1=nc(double(rawMark),double(mark));
emark=uint8(mark);
end